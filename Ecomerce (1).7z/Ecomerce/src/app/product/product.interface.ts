//Interface for products
export interface Iproducts{
    id:string,
    name:string,
    price:number,
    category:string

}